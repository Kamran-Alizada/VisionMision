import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Login from './pages/Login';

// Lazy load other components
const StudentDashboard = React.lazy(() => import('./pages/student/Dashboard'));
const TeacherDashboard = React.lazy(() => import('./pages/teacher/Dashboard'));
const AITutor = React.lazy(() => import('./pages/student/AITutor'));
const Assignments = React.lazy(() => import('./pages/shared/Assignments'));
const Profile = React.lazy(() => import('./pages/shared/Profile'));
const Statistics = React.lazy(() => import('./pages/teacher/Statistics'));
const Timetable = React.lazy(() => import('./pages/shared/Timetable'));
const Notifications = React.lazy(() => import('./pages/shared/Notifications'));

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        
        {/* Student Routes */}
        <Route path="/student" element={<Layout><StudentDashboard /></Layout>} />
        }
        <Route path="/student/timetable" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Timetable />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/student/ai-tutor" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <AITutor />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/student/assignments" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Assignments />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/student/notifications" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Notifications />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/student/profile" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Profile />
            }
            </React.Suspense>
          </Layout>
        } />

        {/* Teacher Routes */}
        <Route path="/teacher" element={<Layout><TeacherDashboard /></Layout>} />
        }
        <Route path="/teacher/class-info" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <TeacherDashboard />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/teacher/statistics" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Statistics />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/teacher/assignments" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Assignments />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/teacher/notifications" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Notifications />
            }
            </React.Suspense>
          </Layout>
        } />
        <Route path="/teacher/profile" element={
          <Layout>
            <React.Suspense fallback={<div>Loading...</div>}>
              <Profile />
            }
            </React.Suspense>
          </Layout>
        } />

        <Route path="/logout" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;