import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { 
  Calendar, 
  BookOpen, 
  ClipboardList, 
  User, 
  LogOut, 
  BarChart2, 
  Users,
  Bell
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const isTeacher = location.pathname.includes('/teacher');
  
  const studentLinks = [
    { icon: Calendar, label: 'Timetable', path: '/student/timetable' },
    { icon: BookOpen, label: 'AI Tutor', path: '/student/ai-tutor' },
    { icon: ClipboardList, label: 'Assignments', path: '/student/assignments' },
    { icon: Bell, label: 'Notifications', path: '/student/notifications' },
    { icon: User, label: 'Profile', path: '/student/profile' },
  ];

  const teacherLinks = [
    { icon: Users, label: 'Class Info', path: '/teacher/class-info' },
    { icon: BarChart2, label: 'Statistics', path: '/teacher/statistics' },
    { icon: ClipboardList, label: 'Assignments', path: '/teacher/assignments' },
    { icon: Bell, label: 'Notifications', path: '/teacher/notifications' },
    { icon: User, label: 'Profile', path: '/teacher/profile' },
  ];

  const links = isTeacher ? teacherLinks : studentLinks;

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-blue-600">EduGuard</h1>
        </div>
        <nav className="mt-6">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center px-6 py-3 text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                location.pathname === link.path ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              <link.icon className="w-5 h-5 mr-3" />
              {link.label}
            </Link>
          ))}
          <Link
            to="/logout"
            className="flex items-center px-6 py-3 text-red-600 hover:bg-red-50 transition-colors mt-auto"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </Link>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {children}
        </div>
      </div>
    </div>
  );
}