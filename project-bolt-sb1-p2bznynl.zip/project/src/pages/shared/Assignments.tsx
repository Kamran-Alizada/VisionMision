import React from 'react';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';
import type { Assignment } from '../../types';

const assignments: Assignment[] = [
  {
    id: '1',
    title: 'Mathematics Homework - Chapter 5',
    dueDate: '2024-03-15',
    status: 'completed'
  },
  {
    id: '2',
    title: 'Physics Lab Report',
    dueDate: '2024-03-20',
    status: 'in-progress'
  },
  {
    id: '3',
    title: 'History Essay',
    dueDate: '2024-03-25',
    status: 'pending'
  },
];

const statusIcons = {
  completed: CheckCircle,
  'in-progress': Clock,
  pending: AlertCircle,
};

const statusColors = {
  completed: 'text-green-500',
  'in-progress': 'text-yellow-500',
  pending: 'text-red-500',
};

export default function Assignments() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Assignments</h1>
      
      <div className="grid gap-6">
        {assignments.map((assignment) => {assignments.map((assignment) => {
          const StatusIcon = statusIcons[assignment.status];
          return (
            <div key={assignment.id} className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <StatusIcon className={`w-6 h-6 ${statusColors[assignment.status]}`} />
                  <div>
                    <h2 className="text-lg font-semibold text-gray-800">{assignment.title}</h2>
                    <p className="text-sm text-gray-500">
                      Due: {new Date(assignment.dueDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    assignment.status === 'completed' ? 'bg-green-100 text-green-800' :
                    assignment.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {assignment.status.replace('-', ' ')}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
        )
        }
      </div>
    </div>
  );
}