import React, { useState } from 'react';
import { Bell, Check } from 'lucide-react';
import type { Notification } from '../../types';

const mockNotifications: Notification[] = [
  {
    id: '1',
    title: 'New Assignment',
    message: 'Mathematics homework due tomorrow',
    date: '2024-03-14T10:00:00Z',
    read: false
  },
  {
    id: '2',
    title: 'Exam Reminder',
    message: 'Physics exam next week',
    date: '2024-03-13T15:30:00Z',
    read: true
  },
  {
    id: '3',
    title: 'Grade Posted',
    message: 'Your History essay grade has been posted',
    date: '2024-03-12T09:15:00Z',
    read: false
  }
];

export default function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">Notifications</h1>
        <button
          onClick={markAllAsRead}
          className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Mark all as read
        </button>
      </div>
      
      <div className="space-y-4">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`bg-white p-4 rounded-lg shadow-md ${
              !notification.read ? 'border-l-4 border-blue-600' : ''
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4">
                <div className={`mt-1 ${!notification.read ? 'text-blue-600' : 'text-gray-400'}`}>
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-800">{notification.title}</h2>
                  <p className="text-gray-600">{notification.message}</p>
                  <p className="text-sm text-gray-500 mt-1">
                    {new Date(notification.date).toLocaleString()}
                  </p>
                </div>
              </div>
              {!notification.read && (
                <button
                  onClick={() => markAsRead(notification.id)}
                  className="p-2 text-gray-400 hover:text-gray-600 focus:outline-none"
                >
                  <Check className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}