import React from 'react';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
const timeSlots = ['9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '2:00 PM', '3:00 PM'];

const schedule = {
  Monday: [
    { time: '9:00 AM', subject: 'Mathematics', teacher: 'Dr. Smith' },
    { time: '10:00 AM', subject: 'Physics', teacher: 'Mrs. Johnson' },
    { time: '11:00 AM', subject: 'English', teacher: 'Mr. Davis' },
  ],
  Tuesday: [
    { time: '9:00 AM', subject: 'Chemistry', teacher: 'Dr. Wilson' },
    { time: '10:00 AM', subject: 'History', teacher: 'Mrs. Brown' },
    { time: '2:00 PM', subject: 'Biology', teacher: 'Mr. Thompson' },
  ],
  // Add more days...
};

export default function Timetable() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Weekly Timetable</h1>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time
                </th>
                {days.map(day => (
                  <th key={day} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {timeSlots.map(time => (
                <tr key={time}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {time}
                  </td>
                  {days.map(day => {
                    const session = schedule[day]?.find(s => s.time === time);
                    return (
                      <td key={`${day}-${time}`} className="px-6 py-4 whitespace-nowrap">
                        {session ? (
                          <div className="bg-blue-50 p-2 rounded-lg">
                            <div className="text-sm font-medium text-blue-800">
                              {session.subject}
                            </div>
                            <div className="text-xs text-blue-600">
                              {session.teacher}
                            </div>
                          </div>
                        ) : null}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}