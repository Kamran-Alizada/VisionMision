import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const performanceData = [
  { subject: 'Mathematics', score: 85 },
  { subject: 'Science', score: 92 },
  { subject: 'History', score: 78 },
  { subject: 'English', score: 88 },
  { subject: 'Physics', score: 95 },
];

export default function StudentDashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Student Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Performance Overview */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Performance Overview</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="subject" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Upcoming Tasks */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Upcoming Tasks</h2>
          <div className="space-y-4">
            {[
              { title: 'Mathematics Quiz', date: 'Tomorrow, 10:00 AM' },
              { title: 'History Essay Submission', date: 'Friday, 3:00 PM' },
              { title: 'Science Lab Report', date: 'Next Monday' },
            ].map((task, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                <div>
                  <h3 className="font-medium text-gray-800">{task.title}</h3>
                  <p className="text-sm text-gray-500">{task.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activities */}
        <div className="bg-white p-6 rounded-lg shadow-md md:col-span-2">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Recent Activities</h2>
          <div className="space-y-4">
            {[
              { activity: 'Completed Mathematics Assignment', time: '2 hours ago' },
              { activity: 'Attended Physics Class', time: '4 hours ago' },
              { activity: 'Submitted English Essay', time: 'Yesterday' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center justify-between border-b pb-3">
                <span className="text-gray-800">{activity.activity}</span>
                <span className="text-sm text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}