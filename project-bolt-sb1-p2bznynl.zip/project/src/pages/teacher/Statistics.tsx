import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';

const performanceData = [
  { month: 'Jan', attention: 85, engagement: 80 },
  { month: 'Feb', attention: 88, engagement: 85 },
  { month: 'Mar', attention: 92, engagement: 88 },
  { month: 'Apr', attention: 90, engagement: 85 },
  { month: 'May', attention: 95, engagement: 92 },
];

const subjectPerformance = [
  { subject: 'Mathematics', score: 85 },
  { subject: 'Physics', score: 78 },
  { subject: 'Chemistry', score: 92 },
  { subject: 'Biology', score: 88 },
];

const attentionDistribution = [
  { name: 'High', value: 45 },
  { name: 'Medium', value: 35 },
  { name: 'Low', value: 20 },
];

const COLORS = ['#3B82F6', '#10B981', '#EF4444'];

export default function Statistics() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Class Statistics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Performance Trends */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Performance Trends</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="attention" stroke="#3B82F6" />
                <Line type="monotone" dataKey="engagement" stroke="#10B981" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subject Performance */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Subject Performance</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectPerformance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="subject" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attention Distribution */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Attention Distribution</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attentionDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {attentionDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Summary Statistics */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Summary Statistics</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h3 className="text-sm font-medium text-blue-800">Average Attention</h3>
              <p className="text-2xl font-bold text-blue-600">90%</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <h3 className="text-sm font-medium text-green-800">Average Engagement</h3>
              <p className="text-2xl font-bold text-green-600">86%</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <h3 className="text-sm font-medium text-purple-800">Total Students</h3>
              <p className="text-2xl font-bold text-purple-600">45</p>
            </div>
            <div className="p-4 bg-yellow-50 rounded-lg">
              <h3 className="text-sm font-medium text-yellow-800">Active Classes</h3>
              <p className="text-2xl font-bold text-yellow-600">4</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}