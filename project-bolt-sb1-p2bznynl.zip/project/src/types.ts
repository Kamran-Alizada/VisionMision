export interface User {
  id: string;
  name: string;
  role: 'student' | 'teacher';
  email: string;
  avatar?: string;
}

export interface Assignment {
  id: string;
  title: string;
  dueDate: string;
  status: 'completed' | 'in-progress' | 'pending';
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
}

export interface ClassSession {
  id: string;
  subject: string;
  time: string;
  teacher: string;
}